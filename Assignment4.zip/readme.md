I use different languages for different assignments.
In assignment1, I used C++.
In assignment2, I used Python.
In assignment4, I used JavaScript.
To run my code, please open the html file.